# -*- coding: utf-8 -*-
from irc3.template import main


if __name__ == '__main__':
    main()
